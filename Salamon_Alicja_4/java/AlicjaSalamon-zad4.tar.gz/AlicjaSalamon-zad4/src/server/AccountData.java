package server;

import java.io.Serializable;

public class AccountData implements Serializable {
	
	boolean logged;
	boolean registered;
	long balance;
	String login;
	
	public AccountData(boolean logged, boolean registered, long balance, String login) {
		super();
		this.logged = logged;
		this.registered = registered;
		this.balance = balance;
		this.login = login;
	}
	
	

}
