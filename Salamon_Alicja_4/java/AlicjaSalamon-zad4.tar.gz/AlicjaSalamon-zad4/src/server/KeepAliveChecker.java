package server;

import java.util.Map;

import Bank.AccountNotRegistered;
import Bank.NotLogined;

public class KeepAliveChecker extends Thread {

	Map<String, AccountI> map;

	public KeepAliveChecker(Map<String, AccountI> map) {
		this.map = map;
	}

	public void run() {

		while (true) {

			System.out.println("sprawdzam");
			for (AccountI i : map.values()) {
				if (System.currentTimeMillis() - i.pingTime > 30000) {
					try {
						if (i.accountData==null) {
							System.out.println("dupa");
						}
						System.out.println("wylogowuje");
						i.logOut();
					} catch (AccountNotRegistered e) {
						e.printStackTrace();
					} catch (NotLogined e) {
						e.printStackTrace();
					}
				}

			}
			try {
				Thread.sleep(30000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
