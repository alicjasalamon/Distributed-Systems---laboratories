package server;

import java.util.Map;

import Ice.Current;
import Ice.LocalObjectHolder;
import Ice.Object;
import Ice.UserException;

public class MyServantLocator1 implements Ice.ServantLocator {

	Map<String, AccountI> map;
	AccountI accountI;
	
	public MyServantLocator1(Map<String, AccountI> map) {
		this.map = map;
		accountI = new AccountI(map);
	}

	
	@Override
	public Object locate(Current curr, LocalObjectHolder cookie)
			throws UserException {

	//	System.out.println("locate");
		return accountI;
	}

	@Override
	public void finished(Current curr, Object servant, java.lang.Object cookie)
			throws UserException {
	//	System.out.println("finished");
		
	}

	@Override
	public void deactivate(String category) {
//		System.out.println("deactivate");
		
	}

}
