package server;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class Server {

	static Map<String, AccountI> map = new HashMap<String, AccountI>();
	
	public void t1(String[] args) {

		int status = 0;
		Ice.Communicator ic = null;


		try {

			ic = Ice.Util.initialize(args);
			Ice.ObjectAdapter adapter = ic.createObjectAdapter("Adapter11");

			BankManagerI bankManagerI = new BankManagerI();
			Ice.Object obj = bankManagerI;

			// ////////////////////////////////////////////////
			// SERVANT LOCATOR //
			// ////////////////////////////////////////////////
			
			InputStream stream = new FileInputStream("server.properties");
			Properties p = new Properties();
			p.load(stream);
			stream.close();
			
			Ice.ServantLocator mylocator = null;
			
			if (p.getProperty("mode").equals("1"))
					 mylocator= new MyServantLocator1(map);
			else if (p.getProperty("mode").equals("2")){
				
				 mylocator= new MyServantLocator2(map);
			}
			
			adapter.addServantLocator(mylocator, "");
			
			adapter.add(obj, ic.stringToIdentity("sr1"));
			adapter.activate();

			try {
				ic.waitForShutdown();
			} finally {
			}

			ic.waitForShutdown();
		} catch (Exception e) {
			System.err.println(e);
			status = 1;
		}
		if (ic != null) {
			// Clean up
			//
			try {
				ic.destroy();
			} catch (Exception e) {
				System.err.println(e);
				status = 1;
			}
		}
		System.exit(status);
	}

	public static void main(String[] args) throws NumberFormatException,
			IOException {

		System.out.println("dziala");
		KeepAliveChecker r = new KeepAliveChecker(map);
		Thread t = new Thread(r);
		t.start();
		Server app = new Server();
		app.t1(args);
		System.out.println("koniec");

	}

}
