package server;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import Bank.AccountAlreadyRegistered;
import Bank._BankManagerDisp;
import Ice.Current;
import Ice.ObjectAdapter;

public class BankManagerI extends _BankManagerDisp {


	@Override
	public String register(String pesel, Current __current)
			throws AccountAlreadyRegistered {

		System.out.println("rejestracja!");
		String password = new StringBuilder(pesel).reverse().toString();
		File f = new File(password);
		if (f.exists()) {
			throw new AccountAlreadyRegistered();
		} else {

			AccountData accountData = new AccountData(false, true, 0, pesel);
			ObjectOutputStream out;
			try {
				out = new ObjectOutputStream(new FileOutputStream(password));
				out.writeObject(accountData);
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
		
		return password;
	}

}
