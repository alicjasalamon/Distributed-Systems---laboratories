package server;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import SR.CertSignerPrx;
import SR.CertSignerPrxHelper;

public class CertificatSigner extends Ice.Application {

	class ShutdownHook extends Thread {
		public void run() {
			try {
				communicator().destroy();
			} catch (Ice.LocalException ex) {
				ex.printStackTrace();
			}
		}
	}

	@Override
	public int run(String[] args) {
			
			
		try {

			setInterruptHook(new ShutdownHook());

			CertSignerPrx certSignerPtx = CertSignerPrxHelper
					.checkedCast(communicator().propertyToProxy("Signer.Proxy"));

			String name = args[0];
			File myFile = new File(name);
			DataInputStream inputStream = new DataInputStream(new FileInputStream(myFile));
			
			byte[] buffer = new byte[(int) myFile.length()];
			inputStream.readFully(buffer);
			FileOutputStream fileOutputStream = new FileOutputStream(args[1]);
			fileOutputStream.write(certSignerPtx.signCSR("alicja", "salamon", buffer));
			
			fileOutputStream.close();
			inputStream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return 0;
	}

	public static void main(String[] args) {
		CertificatSigner app = new CertificatSigner();
		int status = app.main("Client", args, "config.signer");
		System.exit(status);
	}

}
