package server;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Map;
import java.util.Properties;

import Bank.AccountNotRegistered;
import Bank.ImproperBalance;
import Bank.NotLogined;
import Bank._AccountDisp;
import Ice.Current;

public class AccountI extends _AccountDisp {

	AccountData accountData = null;
	Map<String, AccountI> map;
	long pingTime=0;
	
	public AccountI(Map<String, AccountI> map) {
		super();
		this.map = map;
	}
	

	@Override
	public void logIn(String l, Current __current) throws AccountNotRegistered {

		// odserializuj co trzeba
		try {
			ObjectInputStream in = new ObjectInputStream(new FileInputStream(l));
			accountData = (AccountData) in.readObject();
			in.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (!accountData.registered)
			throw new AccountNotRegistered();

		accountData.logged = true;
	}

	@Override
	public void logOut(Current __current) throws AccountNotRegistered,
			NotLogined {

		if (!accountData.registered)
			throw new AccountNotRegistered();

		if (accountData.logged == false)
			throw new NotLogined();
		
		map.remove(__current.id.name);

		accountData.logged = false;
		accountData = null;
	}

	@Override
	public long checkBalance(Current __current) throws NotLogined {
		if (accountData.logged == false)
			throw new NotLogined();
		return accountData.balance;
	}

	@Override
	public long changeBalance(long l, Current __current)
			throws ImproperBalance, NotLogined {

		if (accountData.logged == false)
			throw new NotLogined();
		if (accountData.balance + l < 0)
			throw new ImproperBalance();

		accountData.balance += l;

		// zserializuj
		ObjectOutputStream out;
		try {
			out = new ObjectOutputStream(
			new FileOutputStream(accountData.login));
			out.writeObject(accountData);
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return accountData.balance;
	}

	@Override
	public void keepAlive(Current __current) {
		pingTime = System.currentTimeMillis();
		
	}

}
